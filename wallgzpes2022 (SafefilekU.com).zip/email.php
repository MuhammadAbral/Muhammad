<?php
$emailku = 'bossklenyem@gmail.com'; // Ky xD
?>